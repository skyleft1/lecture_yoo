
#include "header.h"


Board::Board()
{
	wsprintf(local[0],TEXT("��������"));
	wsprintf(local[1],TEXT("�ѱ�"));
	wsprintf(local[2],TEXT("�̱�"));
	wsprintf(local[3],TEXT("�Ϻ�"));
	wsprintf(local[4],TEXT("�߱�"));
	wsprintf(local[5],TEXT("����"));
	wsprintf(local[6],TEXT("�ҷ�"));
	wsprintf(local[7],TEXT("����"));
	wsprintf(local[8],TEXT("�Ƹ���Ƽ��"));
	wsprintf(local[9],TEXT("�׸���"));
	wsprintf(local[10],TEXT("������"));
	wsprintf(local[11],TEXT("������"));
	wsprintf(local[12],TEXT("����Ʈ���ϸ���"));
	wsprintf(local[13],TEXT("��Ű"));
	wsprintf(local[14],TEXT("������"));
	wsprintf(local[15],TEXT("����Ʈ"));

/*	local[0] = "��������";	local[1] = "�ѱ�";	local[2]="�̱�";	local[3]="�Ϻ�";	local[4]="�߱�";	local[5]="����";
	local[6]="�ҷ�";	local[7]="����";	local[8]="�Ƹ���Ƽ��";	local[9]="�׸���";	local[10]="������";	local[11]="������";
	local[12]="����Ʈ���ϸ���";	local[13]="��Ű";	local[14]="������";	local[15]="����Ʈ";
*/
	for(int i=0; i<MAP; i++)
	{
		if(i==0)
			own_local[i]=NOTUSE;
		else
			own_local[i]=NONE;
		own_home[i] = 0;
		own_hotel[i] = 0;
	}

	p = &own_local[0];
	ph = &own_home[0];
	pht = &own_hotel[0];
}
int Board::getPassmoney(int loc){		//�����
	int result=0;
	if(own_local[loc] != NONE && own_local[loc] != NOTUSE)
		result = (loc*FIELDPAY)+(own_home[loc]*HOMEPAY*loc)+(own_hotel[loc]*HOTELPAY*loc);
	return result;
}
/*
char* Board::getLocalname(int loc){		// ��ġ�̸� �б�
	char* sloc;
	sloc = new char[10];
	strcpy(sloc, local[loc]);
	return sloc;
	return local[loc];
}
*/
TCHAR* Board::getLocalname(int loc){		// ��ġ�̸� �б�
	return local[loc];
}
//	Ȯ��
int Board::getOwn_local(int loc){	//������Ȯ��
	return own_local[loc];
}
int Board::getOwn_home(int loc){	//���ð���Ȯ��
	return own_home[loc];
}
int Board::getOwn_hotel(int loc){	//ȣ��Ȯ��
	return own_hotel[loc];
}
//	����
int Board::setOwn_local(int loc, int player){	//�����κ���
	if(player == NONE)
	{
		own_local[loc]=NONE;
		return 1;
	}
	else
	{
		if(own_local[loc] == NONE)	{
			own_local[loc]=player;
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
int Board::setOwn_home(int loc, int num){		//���ð�������
	if(own_local[loc] == NONE)
	{
		own_home[loc] = 0;
		return 1;
	}
	else
	{
		if(own_home[loc]+num <= 4){
			own_home[loc]+=num;
			return 1;
		}
		else
		{
			return 0;
		}
	}
}
int Board::setOwn_hotel(int loc){				//ȣ�ں���
	if(own_local[loc] == NONE)
	{
		own_hotel[loc] = 0;
		return 1;
	}
	else
	{
		if(own_home[loc] >= 4)
		{
			if(own_hotel[loc] == 0){
			own_hotel[loc]=1;
				return 1;
			}
			else
			{
				return 0;
			}
		}
		else
		{
			return 0;
		}
	}
}

void Board::boardDraw(HDC hdc)
{
	for(int i=0;i<588;i+=588/5+1)		//���
	{
		Rectangle(hdc,i,0,i+588/5+1,100);
	}
	for(int i=0;i<500;i+=500/5+1)		//���
	{
		Rectangle(hdc,472,i,588,i+500/5+1);
	}
	for(int i=0;i<588;i+=588/5+1)		//�ϴ�
	{
		Rectangle(hdc,i,404,i+588/5+1,504);
	}

	for(int i=0;i<500;i+=500/5+1)		//�´�
	{
		Rectangle(hdc,0,i,118,i+500/5+1);
	}

	TCHAR str[MAP][10];
	for(int i=0; i<MAP; i++)
	{
		wsprintf(str[i],TEXT("%s"),getLocalname(i));
	}
	TextOut(hdc, 2,4,str[0],lstrlen(str[0]));
	TextOut(hdc, 120,4,str[1],lstrlen(str[1]));
	TextOut(hdc, 238,4,str[2],lstrlen(str[2]));
	TextOut(hdc, 356,4,str[3],lstrlen(str[3]));
	TextOut(hdc, 474,4,str[4],lstrlen(str[4]));
	TextOut(hdc, 474,106,str[5],lstrlen(str[5]));
	TextOut(hdc, 474,208,str[6],lstrlen(str[6]));
	TextOut(hdc, 474,310,str[7],lstrlen(str[7]));
	TextOut(hdc, 474,410,str[8],lstrlen(str[8]));
	TextOut(hdc, 356,410,str[9],lstrlen(str[9]));
	TextOut(hdc, 238,410,str[10],lstrlen(str[10]));
	TextOut(hdc,120,410,str[11],lstrlen(str[11])); 
	TextOut(hdc,2,410,str[12],lstrlen(str[12]));
	TextOut(hdc,2,310,str[13],lstrlen(str[13]));
	TextOut(hdc,2,208,str[14],lstrlen(str[14]));
	TextOut(hdc,2,106,str[15],lstrlen(str[15]));
	
}

/////////////////////////////////////////////////////////////////////
/*
int main(void){		//����
	int gameoverplayer=0;
	Board board;
	Player p1(P1,USER), p2(P2,CPU), p3(P3,CPU), p4(P4,CPU);
	srand(time(NULL));
	printf("**BlueMarble**\n\nPress Any Key to Game Start");
	getchar();
	
	system("cls");
	
	while(true)
	{
		p1.User_turn(board,p2,p3,p4);
		p2.User_turn(board,p1,p3,p4);
		p3.User_turn(board,p1,p2,p4);
		p4.User_turn(board,p1,p2,p3);
		
		if(p1.GetUser() == NOPLAYER)
			gameoverplayer++;
		if(p2.GetUser() == NOPLAYER)
			gameoverplayer++;
		if(p3.GetUser() == NOPLAYER)
			gameoverplayer++;
		if(p4.GetUser() == NOPLAYER)
			gameoverplayer++;
		if(gameoverplayer >= 3)
		{
			cout<<"������ �������ϴ�."<<endl;
			Sleep(3000);
			exit(0);
		}
		else
			gameoverplayer=0;
	}
	return 0;
}
*/